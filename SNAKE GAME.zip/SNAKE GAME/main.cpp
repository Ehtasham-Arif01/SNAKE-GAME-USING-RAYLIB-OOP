/////////////////////********************/////////////////////
//                  _____HEADER FILES____
/////////////////////********************/////////////////////

#include <iostream>
#include <raylib.h>   // Raylib library for graphics
#include <deque>      // Standard template library for double-ended calculation.
#include <raymath.h>  // For Raylib's math functions.

using namespace std;

// static variable to track snake's movement.
static bool allowMove = false;  

/*//////////////////////////////////////////////////////////////
   _____Colors used in different parts of the game____
//////////////////////////////////////////////////////////////*/

Color welcomeColor = {34, 167, 240, 255};  // Bright Blue
Color menuColor = {233, 212, 96, 255};     // Soft Gold
Color gameColor = {240, 0, 0, 240};      // Vibrant Red
Color darkColor = {52, 73, 94, 255};       // Dark Slate
Color gameOverColor = {255, 0, 0, 255}; // red


/*//////////////////////////////////////////////////////////////
          _____Constants for game settings.____
//////////////////////////////////////////////////////////////*/

// Size of each cell in the game grid
int cellSize = 25; 
// Number of cells in each row and columns. 
int cellCount = 20; 
// Offset from window edge to game boundry. 
int offset = 50;     
// Time count of the last update
double lastUpdateTime = 0;
// Time count of game over.
double gameOverTime = 0;    


/*//////////////////////////////////////////////////////////////
_____Function to check if a given element exists in a deque____
//////////////////////////////////////////////////////////////*/

bool ElementInDeque(Vector2 element, deque<Vector2> deque)
{
    for (unsigned int i = 0; i < deque.size(); i++)
    {
        if (Vector2Equals(deque[i], element))
        {
            return true;
        }
    }
    return false;
}

/*//////////////////////////////////////////////////////////////
Function to check if a certain time interval has passed since the last event__
//////////////////////////////////////////////////////////////*/

bool EventTriggered(double interval)
{
    double currentTime = GetTime();
    if (currentTime - lastUpdateTime >= interval)
    {
        lastUpdateTime = currentTime;
        return true;
    }
    return false;
}

/*//////////////////////////////////////////////////////////////
Function to check if a mouse button is pressed within a given rectangle____
//////////////////////////////////////////////////////////////*/

bool CheckButtonPress(Rectangle buttonRect)
{
    Vector2 mousePos = GetMousePosition();
    if (CheckCollisionPointRec(mousePos, buttonRect) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON))
    {
        return true;
    }
    return false;
}


/**************************************************************************/
//////////////////////////********************/////////////////////////////
//         _____Class representing the snake in the game____
//////////////////////////********************/////////////////////////////
/*************************************************************************/

class Snake
{
public:
    deque<Vector2> body = {Vector2{6, 9}, Vector2{5, 9}, Vector2{4, 9}};  // Initial snake body
    Vector2 direction = {1, 0};  // Initial movement direction
    bool addSegment = false;      // Flag to add a new segment to the snake


/*//////////////////////////////////////////////////////////////
      _____Method to draw the snake on the screen____
//////////////////////////////////////////////////////////////*/    
 
    void Draw()
    {
        for (unsigned int i = 0; i < body.size(); i++)
        {
            float x = body[i].x;
            float y = body[i].y;
            Rectangle segment = Rectangle{offset + x * cellSize, offset + y * cellSize, (float)cellSize, (float)cellSize};
            DrawRectangleRounded(segment, 0.5, 6, DARKGRAY);  // Draw each segment of the snake
        }
    }


/*//////////////////////////////////////////////////////////////
          _____Method to update the snake's position____
//////////////////////////////////////////////////////////////*/
   
    void Update()
    {
        body.push_front(Vector2Add(body[0], direction));  // Move the snake's head
        if (addSegment == true)
        {
            addSegment = false;
        }
        else
        {
            body.pop_back();  // Remove the last segment if not adding a new one
        }
    }


/*//////////////////////////////////////////////////////////////
 _____Method to reset the snake's position and direction____
//////////////////////////////////////////////////////////////*/

    void Reset()
    {
        body = {Vector2{6, 9}, Vector2{5, 9}, Vector2{4, 9}};
        direction = {1, 0};
    }
};


/**************************************************************************/
//////////////////////////********************/////////////////////////////
//         _____Class representing the food in the game____
//////////////////////////********************/////////////////////////////
/*************************************************************************/


class Food
{
public:
    Vector2 position;   // Position of the food
    Texture2D texture;  // Texture of the food

    // Constructor to initialize food position and texture
    Food(deque<Vector2> snakeBody)
    {
        Image image = LoadImage("Graphics/food.png");  // Load food image
        texture = LoadTextureFromImage(image);        // Load texture from image
        UnloadImage(image);                           // Unload image from memory
        position = GenerateRandomPos(snakeBody);      // Generate random position for food
    }

    // Destructor to unload texture
    ~Food()
    {
        UnloadTexture(texture);  // Unload texture from memory
    }


/*//////////////////////////////////////////////////////////////
        _____Method to draw the food on the screen____
//////////////////////////////////////////////////////////////*/
   
    void Draw()
    {
        DrawTexture(texture, offset + position.x * cellSize, offset + position.y * cellSize, WHITE);  // Draw food texture at its position
    }


/*//////////////////////////////////////////////////////////////
 _____Method to generate a random cell position for food____
//////////////////////////////////////////////////////////////*/

    Vector2 GenerateRandomCell()
    {
        float x = GetRandomValue(0, cellCount - 1);
        float y = GetRandomValue(0, cellCount - 1);
        return Vector2{x, y};
    }


/*//////////////////////////////////////////////////////////////
Method to generate a random position for food that is not occupied by the snake__
//////////////////////////////////////////////////////////////*/
    
    Vector2 GenerateRandomPos(deque<Vector2> snakeBody)
    {
        Vector2 position = GenerateRandomCell();
        while (ElementInDeque(position, snakeBody))
        {
            position = GenerateRandomCell();
        }
        return position;
    }
};


/**************************************************************************/
//////////////////////////********************/////////////////////////////
//               _____Class representing the game____
//////////////////////////********************/////////////////////////////
/*************************************************************************/
   

class Game
{
public:
    Snake snake = Snake();  // Snake object
    Food food = Food(snake.body);  // Food object
    bool running = true;           // Flag to indicate if the game is running
    int score = 0;                 // Player's score
    Sound eatSound;                // Sound played when snake eats food
    Sound wallSound;               // Sound played when snake hits wall

    // Constructor to initialize audio and sounds
    Game()
    {
        InitAudioDevice();
        eatSound = LoadSound("Sounds/eat.mp3");   // Load eat sound
        wallSound = LoadSound("Sounds/wall.mp3"); // Load wall collision sound
    }

    // Destructor to unload sounds and close audio device
    ~Game()
    {
        UnloadSound(eatSound);   // Unload eat sound from memory
        UnloadSound(wallSound);  // Unload wall collision sound from memory
        CloseAudioDevice();      // Close audio device
    }


/*//////////////////////////////////////////////////////////////
    _____Method to draw game objects on the screen____
//////////////////////////////////////////////////////////////*/

    void Draw()
    {
        food.Draw();   // Draw food
        snake.Draw();  // Draw snake
    }


/*//////////////////////////////////////////////////////////////
           _____Method to update game logic____
//////////////////////////////////////////////////////////////*/

    void Update()
    {
        if (running)
        {
            snake.Update();              // Update snake position
            CheckCollisionWithFood();    // Check collision with food
            CheckCollisionWithEdges();   // Check collision with edges
            CheckCollisionWithTail();    // Check collision with own tail
        }
    }


/*//////////////////////////////////////////////////////////////
      _____Method to check collision with food____
//////////////////////////////////////////////////////////////*/

    void CheckCollisionWithFood()
    {
        if (Vector2Equals(snake.body[0], food.position))
        {
            food.position = food.GenerateRandomPos(snake.body);  // Generate new food position
            snake.addSegment = true;                             // Add a new segment to the snake
            score++;                                             // Increment score
            PlaySound(eatSound);                                 // Play eat sound
        }
    }


/*//////////////////////////////////////////////////////////////
      _____Method to check collision with game edges____
//////////////////////////////////////////////////////////////*/

    void CheckCollisionWithEdges()
    {
        if (snake.body[0].x == cellCount || snake.body[0].x == -1)
        {
            GameOver();  // Game over if snake hits horizontal edges
        }
        if (snake.body[0].y == cellCount || snake.body[0].y == -1)
        {
            GameOver();  // Game over if snake hits vertical edges
        }
    }


/*//////////////////////////////////////////////////////////////
            _____Method to handle game over____
//////////////////////////////////////////////////////////////*/
  
    void GameOver()
    {
        PlaySound(wallSound);       // Play wall collision sound
        gameOverTime = GetTime();   // Record game over time
        running = false;            // Stop game
        score = 0;                  // Reset score
        snake.Reset();              // Reset snake position and direction
        food.position = food.GenerateRandomPos(snake.body);  // Generate new food position
    }


/*//////////////////////////////////////////////////////////////
    _____Method to check collision with own tail____
//////////////////////////////////////////////////////////////*/
   
    void CheckCollisionWithTail()
    {
        deque<Vector2> headlessBody = snake.body;
        headlessBody.pop_front();
        if (ElementInDeque(snake.body[0], headlessBody))
        {
            GameOver();  // Game over if snake collides with own tail
        }
    }
};


/**************************************************************************/
//////////////////////////********************/////////////////////////////
//                       _____Main function____
//////////////////////////********************/////////////////////////////
/*************************************************************************/

int main()
{
    InitWindow(2 * offset + cellSize * cellCount, 2 * offset + cellSize * cellCount, "Snake Game");  // Initialize window
    SetTargetFPS(60);  // Set target frames per second

    Game game = Game();  // Create game object

    bool showMenu = true;               // Flag to control menu visibility
    double startTime = GetTime();       // Record start time for welcome message

    // Main game loop
    while (!WindowShouldClose())
    {
        BeginDrawing();
        ClearBackground(welcomeColor);  // Clear the background with welcome color

        // Show welcome message initially for 3 seconds
        if (GetTime() - startTime < 3)
        {
            DrawText("WELCOME TO THE SNAKE GAME", GetScreenWidth() / 2 - MeasureText("WELCOME TO THE SNAKE GAME", 20) / 2, GetScreenHeight() / 2 - 10, 20, DARKGRAY);
        }
        else if (showMenu)
        {
          
            int verticalSpace = 60; 
            int screenWidth = GetScreenWidth();
            int screenHeight = GetScreenHeight();

            Rectangle playButton = {(float)(screenWidth - 200) / 2, (float)(screenHeight - 200) / 2 - verticalSpace, 200, 50}; 
            Rectangle highScoreButton = {(float)(screenWidth - 200) / 2, (float)(screenHeight - 200) / 2, 200, 50}; 
            Rectangle helpButton = {(float)(screenWidth - 200) / 2, (float)(screenHeight - 200) / 2 + verticalSpace, 200, 50}; 
            Rectangle exitButton = {(float)(screenWidth - 200) / 2, (float)(screenHeight - 200) / 2 + 2 * verticalSpace, 200, 50};

            DrawRectangleRec(playButton, BLACK);  
            DrawRectangleRec(exitButton, BLACK); 
            DrawRectangleRec(highScoreButton, BLACK);
            DrawRectangleRec(helpButton, BLACK);      
            DrawText("PLAY", playButton.x + 50, playButton.y + 15, 20, WHITE);  
            DrawText("EXIT", exitButton.x + 50, exitButton.y + 15, 20, WHITE); 
            DrawText("HIGH SCORE", highScoreButton.x + 20, highScoreButton.y + 15, 20, WHITE);  
            DrawText("HELP", helpButton.x + 60, helpButton.y + 15, 20, WHITE);  

            // Check for button press events
            if (CheckButtonPress(playButton))
            {
                showMenu = false;  // Hide menu on play button click
                game.running = true;  // Start the game
            }
            if (CheckButtonPress(exitButton))
            {
                break;  // Exit the application on exit button click
            }
            if (CheckButtonPress(highScoreButton))
            {
                // Implement functionality to display high score
                // For now, let's just print a message
                cout << "High Score: <Your High Score>" << endl;
            }
            if (CheckButtonPress(helpButton))
            {
                // Implement functionality to access help
                // For now, let's just print a message
                cout << "Help: <Instructions on how to play the game>" << endl;
            }

        }
        else // If not in menu mode, update and draw the game
        {
            if (!game.running)
            {
                if (GetTime() - gameOverTime < 3)
                {
                    // Display "GAME OVER" for 3 seconds
                    DrawText("GAME OVER", GetScreenWidth() / 2 - MeasureText("GAME OVER", 40) / 2, GetScreenHeight() / 2 - 20, 40, gameOverColor);
                }
                else
                {
                    showMenu = true;  // Show menu after 3 seconds
                }
            }
            else
            {
                if (EventTriggered(0.2))
                {
                    allowMove = true;  // Allow movement every 0.2 seconds
                    game.Update();     // Update game logic
                }

                // Check keyboard input for snake movement
                if (IsKeyPressed(KEY_UP) && game.snake.direction.y != 1 && allowMove)
                {
                    game.snake.direction = {0, -1};  // Move snake up
                    game.running = true;              // Set game state to running
                    allowMove = false;                // Prevent immediate further movement
                }
                if (IsKeyPressed(KEY_DOWN) && game.snake.direction.y != -1 && allowMove)
                {
                    game.snake.direction = {0, 1};   // Move snake down
                    game.running = true;              // Set game state to running
                    allowMove = false;                // Prevent immediate further movement
                }
                if (IsKeyPressed(KEY_LEFT) && game.snake.direction.x != 1 && allowMove)
                {
                    game.snake.direction = {-1, 0};  // Move snake left
                    game.running = true;              // Set game state to running
                    allowMove = false;                // Prevent immediate further movement
                }
                if (IsKeyPressed(KEY_RIGHT) && game.snake.direction.x != -1 && allowMove)
                {
                    game.snake.direction = {1, 0};   // Move snake right
                    game.running = true;              // Set game state to running
                    allowMove = false;                // Prevent immediate further movement
                }

                // Draw game elements
                DrawRectangleLinesEx(Rectangle{(float)offset - 5, (float)offset - 5, (float)cellSize * cellCount + 10, (float)cellSize * cellCount + 10}, 5, darkColor);  // Draw game border
                DrawText("SNAKE GAME", offset - 5, 20, 30, gameColor);  // Draw game title
                DrawText(TextFormat("%i", game.score), offset - 5, offset + cellSize * cellCount + 10, 40, gameColor);  // Draw current score
                game.Draw();  // Draw game objects
            }
        }

        EndDrawing();  // End drawing frame
    }

    CloseWindow();  // Close window
    return 0;
}
